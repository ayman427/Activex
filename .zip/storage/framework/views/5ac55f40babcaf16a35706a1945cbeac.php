<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Community Forum')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <!-- Post Creation Form -->
        <div class="bg-white shadow rounded-lg p-6 mb-6 dark:bg-gray-800">
            <h2 class="text-xl font-semibold mb-4 dark:text-gray-200">Create a New Post</h2>
            <form method="POST" action="<?php echo e(route('posts.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="title" class="block font-semibold dark:text-gray-200">Title</label>
                    <input type="text" id="title" name="title" class="w-full border rounded px-4 py-2 dark:bg-gray-900 dark:text-gray-400" required>
                </div>
                <div class="mb-4">
                    <label for="content" class="block font-semibold dark:text-gray-200">Content</label>
                    <textarea id="content" name="content" rows="4" class="w-full border rounded px-4 py-2 dark:bg-gray-900 dark:text-gray-400" required></textarea>
                </div>
                <button type="submit" class="bg-black text-white px-4 py-2 rounded hover:bg-blue-600">
                    Post
                </button>
            </form>
        </div>

        <!-- Displaying All Posts -->
        <?php if($posts->isEmpty()): ?>
            <p class="text-gray-500">No posts yet, be the first one to post.</p>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow rounded-lg p-6 mb-6 dark:bg-gray-800">
                    <h2 class="text-xl font-semibold">
                        <a href="<?php echo e(route('post.show', $post)); ?>" class="text-blue-500 dark:text-gray-200">
                            <?php echo e($post->title); ?>

                        </a>
                    </h2>
                    <p class="text-gray-600 mb-2 dark:text-gray-200"><?php echo e($post->content); ?></p>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Posted by <?php echo e($post->user->name); ?> on <?php echo e($post->created_at->format('M d, Y')); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <!-- Pagination Links -->
        <div class="mt-4">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\activex\resources\views/forum/index.blade.php ENDPATH**/ ?>