<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('My Posts')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">

        <?php if($posts->isEmpty()): ?>
            <p class="text-gray-500 dark:text-gray-200">You haven't made any posts yet.</p>
        <?php else: ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow rounded-lg p-6 mb-6 dark:bg-gray-800">
                    <h2 class="text-xl font-semibold">
                        <a href="<?php echo e(route('post.show', $post)); ?>" class="text-blue-500 dark:text-gray-200">
                            <?php echo e($post->title); ?>

                        </a>
                    </h2>
                    <p class="text-gray-600 mb-2 dark:text-gray-200"><?php echo e($post->content); ?></p>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Posted on <?php echo e($post->created_at->format('M d, Y')); ?></p>

                    <!-- Edit and Delete Buttons -->
                    <div class="mt-4 flex space-x-4">
                        <!-- Edit Button with Google Material Icon -->
                        <a href="<?php echo e(route('post.edit', $post)); ?>" class="text-black px-4 py-2 rounded hover:bg-blue-600 flex items-center" style="background-color: #2563eb; margin-right:5px">
                            <span class="material-icons">edit</span>
                        </a>
                        
                        <!-- Delete Button with Google Material Icon -->
                        <form method="POST" action="<?php echo e(route('post.delete', $post)); ?>" class="inline-block" onsubmit="return confirmDelete()">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-black px-4 py-2 rounded hover:bg-blue-600 flex items-center" style="background-color: #d62828;">
                                <span class="material-icons">delete</span>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <script>
        // JavaScript function to confirm deletion
        function confirmDelete() {
            return confirm("Are you sure you want to delete this post?");
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\activex\resources\views/forum/user-posts.blade.php ENDPATH**/ ?>