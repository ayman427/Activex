<?php
namespace App\Http\Controllers;

use App\Models\UserWeight;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class WeightTrackerController extends Controller
{
    public function index()
    {
        // Fetching the user's weights
        $weights = UserWeight::where('user_id', auth()->id())->get();

        // Fetching the user's latest goal weight from the user's weights table
        $goal_weight = UserWeight::where('user_id', auth()->id())->latest()->first()->goal_weight ?? 0; // Default to 0 if no goal weight is set

        $formattedDates = $weights->pluck('created_at')->map(function($date) {
            return $date->format('Y-m-d');
        });

        return view('weight-tracker', compact('weights', 'goal_weight','formattedDates'));
    }

    public function store(Request $request)
    {
        // Validate input
        $request->validate([
            'weight' => 'nullable|numeric|min:1',   // Make weight nullable since we are handling it separately
            'goal_weight' => 'nullable|numeric|min:1',  // Goal weight is optional
        ]);

        // Get today's date
        $today = Carbon::today();

        // Check if a weight entry already exists for the authenticated user on today's date
        $existingWeight = UserWeight::where('user_id', Auth::id())
                                    ->whereDate('date', $today)
                                    ->first();

        // Check if weight is provided and process it
        if ($request->has('weight')) {
            if ($existingWeight) {
                // Update the existing entry with the new weight (and keep the goal_weight if it's not provided)
                $existingWeight->update([
                    'weight' => $request->weight,
                    'goal_weight' => $existingWeight->goal_weight ?? $request->goal_weight,
                ]);
            } else {
                // Create a new entry with the current date and weight
                UserWeight::create([
                    'user_id' => Auth::id(),
                    'weight' => $request->weight,
                    'goal_weight' => $request->goal_weight ?? null,  // Set to null if no goal weight is provided
                    'date' => $today,
                ]);
            }
        }

        // Check if goal weight is provided and process it
        if ($request->has('goal_weight')) {
            // Update the goal weight if it's provided
            if ($existingWeight) {
                $existingWeight->update([
                    'goal_weight' => $request->goal_weight,
                ]);
            } else {
                // Create a new entry if no existing weight entry
                UserWeight::create([
                    'user_id' => Auth::id(),
                    'goal_weight' => $request->goal_weight,
                    'date' => $today,
                ]);
            }
        }

        // Redirect back to the weight tracker page
        return redirect()->route('weight-tracker.index');
    }
}
